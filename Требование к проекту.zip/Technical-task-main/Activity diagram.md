# Содержание
1. [Добавление аудиофайла](#1)
2. [Начало воспроизведения](#2)
3. [Воспроизведение следующей аудиозаписи](#3)
4. [Изменение громкости](#4)
5. [Удаление аудиозаписи](#5)

### 1. Добавление аудиофайла<a name="1"></a>

![Добавление аудиофайла](https://github.com/stptpv/Technical-task/blob/main/Add.png)

### 2. Начало воспроизведения<a name="2"></a>

![Начало воспроизведения](https://github.com/stptpv/Technical-task/blob/main/Play.png)
  
### 3. Воспроизведение следующей аудиозаписи<a name="3"></a>
![Воспроизведение следующей аудиозаписи](https://github.com/stptpv/Technical-task/blob/main/Next.png)

### 4. Изменение громкости<a name="4"></a>
![Изменение громкости](https://github.com/stptpv/Technical-task/blob/main/Volume.png)
### 5. Удаление аудиозаписи<a name="5"></a>
![Удаление аудиозаписи](https://github.com/stptpv/Technical-task/blob/main/Remove.png)
